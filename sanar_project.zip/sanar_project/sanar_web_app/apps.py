from django.apps import AppConfig


class SanarWebAppConfig(AppConfig):
    name = 'sanar_web_app'
